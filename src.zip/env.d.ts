/// <reference types="astro/client" />


interface Window {
    dataLayer: any[]
}