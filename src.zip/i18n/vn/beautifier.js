export default {
    title: 'Công cụ Làm đẹp Ảnh chụp màn hình Trực tuyến',
    description: 'Công cụ Làm đẹp Ảnh chụp màn hình Trực tuyến giúp làm đẹp ảnh chụp màn hình của bạn với hình nền đẹp và khung Macbook Pro hoặc Iphone 15 Pro',
    not: 'Không tải lên và chỉnh sửa trong trình duyệt',
    new: 'Phiên bản mới do LeaferJs phát triển, hãy sử dụng ngay',
    online: 'Làm đẹp Ảnh chụp màn hình Trực tuyến',
    onlineCont: 'Công cụ Làm đẹp Ảnh chụp màn hình giúp làm đẹp ảnh chụp màn hình và ảnh của bạn với một bộ sưu tập hình nền tuyệt vời. Chọn ảnh chụp màn hình của bạn và chọn chủ đề mong muốn và nhận ảnh của bạn.',
    what: 'Bạn có thể làm gì với Công cụ Làm đẹp Ảnh chụp màn hình?',
    whatCont1: 'Nó giúp tạo ra ảnh tuyệt vời bằng cách thêm hình nền đẹp với ảnh chụp màn hình của bạn và tải xuống một bức ảnh đẹp có thể được chia sẻ trên Facebook, Twitter và các diễn đàn Web.',
    whatCont2: 'Người dùng có thể tải xuống hình ảnh đẹp với kích thước hoàn hảo và chất lượng tốt.',
    whatCont3: 'Công cụ Làm đẹp Ảnh chụp màn hình Trực tuyến hoạt động tốt trên Windows, MAC, Linux, Chrome, Firefox, Edge và Safari.'
}