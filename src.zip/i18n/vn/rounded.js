export default {
    title: 'Chuyển Ảnh Thành Hình Tròn',
    description: 'Công cụ trực tuyến chuyển ảnh thành hình tròn, nhanh chóng thêm bo tròn cho ảnh, tạo ra ảnh bo tròn đẹp, kích thước của phần bo tròn, tạo ảnh bo tròn ở định dạng PNG.',
    tip: 'Không tải lên và chỉnh sửa trong trình duyệt',
    online: 'Chuyển Ảnh Thành Hình Tròn Trực Tuyến',
    onlineCont: 'Công cụ trực tuyến chuyển ảnh thành hình tròn, nhanh chóng thêm bo tròn cho ảnh, tạo ra ảnh bo tròn đẹp, kích thước của phần bo tròn, tạo ảnh bo tròn ở định dạng PNG.',
    what: 'Bạn có thể làm gì với Công cụ Chuyển Ảnh Thành Hình Tròn?',
    whatCont1: 'Nó giúp thêm bo tròn cho ảnh và tải xuống một bức ảnh đẹp có thể được chia sẻ trên Facebook, Twitter và các diễn đàn Web.',
    whatCont2: 'Người dùng có thể tải xuống hình ảnh đẹp với kích thước hoàn hảo và chất lượng tốt.',
    whatCont3: 'Công cụ Chuyển Ảnh Thành Hình Tròn Trực Tuyến hoạt động tốt trên Windows, MAC, Linux, Chrome, Firefox, Edge và Safari.'
}