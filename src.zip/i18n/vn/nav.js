export default {
    editor: {
        name: 'Trình Chỉnh Sửa',
        title: 'Trình Chỉnh Sửa Ảnh'
    },
    beautifier: {
        name: 'Làm Đẹp',
        title: 'Làm Đẹp Ảnh Chụp Màn Hình'
    },
    rounded: {
        name: 'Bo Góc',
        title: 'Chuyển Ảnh Thành Hình Tròn'
    },
    remover: {
        name: 'Gỡ Bỏ',
        title: 'Gỡ Bỏ Nền Ảnh'
    },
    compressor: {
        name: 'Nén',
        title: 'Nén Ảnh'
    },
    screenshot: {
        name: 'ảnh chụp màn hình',
        title: 'chụp ảnh màn hình'
    }
}