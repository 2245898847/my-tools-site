export default {
    title: 'Photo To Rounded',
    description: 'Online photo to rounded tool, quickly add rounded to the photo, made of beautiful rounded photo, size of the rounded, generate rounded photo in PNG format.',
    tip: 'Not uploaded and editing in browser',
    online: 'Photo To Rounded Online',
    onlineCont: 'Online photo to rounded tool, quickly add rounded to the photo, made of beautiful rounded photo, size of the rounded, generate rounded photo in PNG format.',
    what: 'What can you do with Photo To Rounded Tool?',
    whatCont1: 'It helps to rounded to the photo and download a beautiful picture that can be shared on Facebook, Twitter and Web forums.',
    whatCont2: 'Users can download beautiful pictures with the perfect size and good quality.',
    whatCont3: 'Online Photo To Rounded Online tool works well on Windows, MAC, Linux, Chrome, Firefox, Edge, and Safari.'
}