export default {
    title: 'Screenshot Beautifier Online',
    description: 'Screenshot Beautifier Online tool is helps to beautify your screnshots with good background and Macbook Pro or Iphone 15 Pro frame',
    not: 'Not uploaded and editing in browser',
    new: 'The new version, developed by LeaferJs, use it now',
    online: 'Screenshot Beautifier Online',
    onlineCont: 'Screenshot Beautifier tool helps to beautify your screenshot and photo with an amazing collection of backgrounds. Select your screenshot and choose your desired theme and get your picture.',
    what: 'What can you do with Screenshot Beautifier Tool?',
    whatCont1: 'It helps to create amazing picture by adding good background with your screenshot and download a beautiful picture that can be shared on Facebook, Twitter and Web forums.',
    whatCont2: 'Users can download beautiful pictures with the perfect size and good quality.',
    whatCont3: 'Online Screenshot Beautifier tool works well on Windows, MAC, Linux, Chrome, Firefox, Edge, and Safari.'
}