export default {
    editor: {
        name: 'Editor',
        title: 'Photo Editor'
    },
    beautifier: {
        name: 'Beautifier',
        title: 'Screenshot Beautifier'
    },
    rounded: {
        name: 'Rounded',
        title: 'Photo to Rounded'
    },
    remover: {
        name: 'Remover',
        title: 'Photo Background Remover'
    },
    compressor: {
        name: 'Compressor',
        title: 'Image Compressor'
    },
    screenshot: {
        name: 'Screenshot',
        title: 'Take a screenshot'
    }
}
