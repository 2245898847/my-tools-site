export default {
    title: 'Screenshot Beautifier Online',
    description: 'Screenshot Beautifier Online tool helps to beautify your screenshots with good background and Macbook Pro or iPhone 15 Pro frame',
    not: 'Not uploaded and editing in browser',
    new: 'The new version, developed by LeaferJs, use it now',
    online: 'Screenshot Beautifier Online',
    onlineCont: 'Screenshot Beautifier tool helps to beautify your screenshot and photo with an amazing collection of backgrounds. Select your screenshot and choose your desired theme and get your picture.',
    what: 'What can you do with Screenshot Beautifier Tool?',
    whatCont1: 'It helps to create an amazing picture by adding a good background to your screenshot and downloading a beautiful picture that can be shared on Facebook, Twitter, and Web forums.',
    whatCont2: 'Users can download beautiful pictures with the perfect size and good quality.',
    whatCont3: 'Online Screenshot Beautifier tool works well on Windows, Mac, Linux, Chrome, Firefox, Edge, and Safari.'
}
