export default {
    editor: {
        name: 'Редактор',
        title: 'Фоторедактор',
    },
    beautifier: {
        name: 'Оформитель',
        title: 'Оформитель скриншотов',
    },
    rounded: {
        name: 'Закругленный',
        title: 'Фото в закругленную форму',
    },
    remover: {
        name: 'Удалитель',
        title: 'Удалитель фона фотографии',
    },
    compressor: {
        name: 'Компрессор',
        title: 'Компрессор изображений',
    },
    screenshot: {
        name: 'скриншот',
        title: 'сделать скриншот'
    }
};
