export default {
    editor: {
        name: '编辑',
        title: '照片编辑器',
    },
    beautifier: {
        name: '美化',
        title: '在线截图编辑美化',
    },
    rounded: {
        name: '圆角',
        title: '照片转圆角',
    },
    remover: {
        name: '抠图',
        title: '照片背景移除',
    },
    compressor: {
        name: '压缩',
        title: '图片快速压缩',
    },
    screenshot: {
        name: '截图',
        title: '在线截图'
    }
};
