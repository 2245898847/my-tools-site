export default {
    editor: {
        name: 'Éditeur',
        title: 'Éditeur de Photos',
    },
    beautifier: {
        name: 'Embellisseur',
        title: "Embellisseur de Captures d'Écran",
    },
    rounded: {
        name: 'Arrondi',
        title: 'Photo vers Arrondie',
    },
    remover: {
        name: 'Supprimeur',
        title: "Supprimeur d'Arrière-Plan de Photo",
    },
    compressor: {
        name: 'Compresseur',
        title: "Compresseur d'Images",
    },
    screenshot: {
        name: 'capture d\'écran',
        title: 'prendre une capture d\'écran'
    }
};
